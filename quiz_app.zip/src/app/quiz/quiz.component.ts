import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  form: FormGroup;
  correctAnsCount=0;
  
  submitFlag=false;
  questions = [
    { 
      question: 'Which is the latest version of angular?',
      option1: '10',
      option2: '11',
      option3: '9',
      option4: '8',
      correctAnswer:'11'
    },
    {
      question: "Which element is used to loop over in angular?",
      option1: 'ngIf',
      option2: 'ngFor',
      option3: 'ngModel',
      option4: 'ngClass',
      correctAnswer:'ngFor'
  },
  {
      question: "Which element is used to check condition in angular?",
      option1: 'ngIf',
      option2: 'ngFor',
      option3: 'ngModel',
      option4: 'ngClass',
      correctAnswer:'ngIf'
  },
  { 
      question: "In angular, Which model is used for routing?",
      option1: 'RouterModule',
      option2: 'BrowserModule',
      option3: 'FormsModule',
      option4: 'NgModule',
      correctAnswer:'RouterModule'
  }
  ]
  totalCount = this.questions.length;
  constructor(private _fb: FormBuilder) {
    this.form = _fb.group({});
    this.questions.forEach(question => {
      this.form.addControl(question.question, _fb.control(null, Validators.required));
    })
  }

  ngOnInit(): void {
  }


  
  onSubmit(f){
    this.correctAnsCount =0
    let questionSet = Object.keys(f.value)
    let answerSet = Object.values(f.value)

    for(let i=0;i<this.questions.length;i++){
      if(this.questions[i].question==questionSet[i]){
        if(this.questions[i].correctAnswer==answerSet[i]){
          this.correctAnsCount = this.correctAnsCount+1
        }
      }
    }
    this.submitFlag=true;
    console.log(this.correctAnsCount)
    
  }
}
