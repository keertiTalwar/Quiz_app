import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class QuizService {
  questionNum: number;
  answers = [];
  url = environment.url
  constructor(private http:HttpClient) { }

  getQuestions(){
    return this.http.get(this.url)
  }

}
